# Questions and Answers

Common questions about the service

What is Hitfile.com?

Hitfile.com is a free cloud storage service where you can upload your files, store them, share files with your friends by providing them with links to your files, and download your friends’ files using links they provide.

Where I can read about your rules?

You can read the rules and conditions for our service on this page: [https://hitfile.net/rules](https://hitfile.net/rules)

Does your site use only one language?

No, our service is multilingual. Hitfile.com is used in many countries of the world and our website supports several important languages. The language of our site is selected automatically based on your browser settings. And also, you can always switch the website language manually.

How and where can I sign up?

You can sign up fast at [https://hitfile.net/reg](https://hitfile.net/reg) — you will need to enter a real email address, to make up a password for your account, and to agree to the rules of our service.

What security measures can I use with my account?

We provide several basic elements to ensure the security of your account:

**Security code** \- we will ask you to confirm your security code when you choose to delete a file. Be careful not to lose your security code, since it cannot be restored. The new security code will be activated in 15 days, during which time all file removal operations will be frozen.

**Password hacking prevention system** \- turn on/off the limit of unsuccessful login attempts. After 10 unsuccessful attempts, you will have to confirm authorization via email. The security system blocks attempts to sign in using that user name for 12 hours. Until the block is removed, all attempts of authorization will be unsuccessful.

**Captcha** \- in addition to your user name and password, the security system on the sign-in page can request you to identity random characters from a picture (captcha).

How can I contact you?

If you have any questions about our service you can write to our support desk. To do this, send a message via our support portal at [help2.hitfile.net](https://hitfile.net/help2.hitfile.net) and wait for our response. You will receive an answer within a short period of time. To ensure that your question is dealt with as quickly as possible, please take care to select the specific department of our support desk to which you want to write. In addition, please refrain from creating several identical requests relating to the same problem: this will only make processing your question slower.

We also provide support in online chats and by email:

Skype: roman.Hitfile.com

ICQ: 574295970

Email: roman@Hitfile.com

I want to download the file

What download speed I will receive in free mode?

The file download speed in free mode is approximately 55-60 Kbytes/s.

How can I download a file in free mode?

On the download page belonging to any file you will be offered two methods of downloading: 'Regular Download' and 'High Speed Download' (buying premium access). If you need free download, just click 'Regular Download'. If you do not want to obtain Turbo (premium) access, undergo testing to show that 'You are not a robot', wait during the time-out, and you will receive a link to slow download of the file.

What download speed will I get if I become a Turbo (premium) user?

Download speed for a Turbo (premium) user is about 1 Gb/s, if your connection allows it.

Why is my download speed is low?

A low download or upload speed may be due to your provider’s settings and internet channel. If the file you are downloading is being downloaded by several users simultaneously, this may also result in a low download speed because our servers will distribute the load equally between the users. To avoid this and gain download priority, you may either become a Turbo (premium) user or try downloading at a different time of day.

Begin the download again using a new premium link. Clear your browser’s cache and cookies and try again. Try another browser (the latest version). Check your internet connection. Check your antivirus, adblock or firewall.

Also, if you experience low download speed or if the download fails, please try using a download manager (for example JDownloader).

What maximum download speed I will receive on my Internet connection?

There are eight bits to the byte, and 1 Mbit/s. = 1024 Kbp/s., thus you can calculate the approximate download speed of your Internet connection according to this formula:

Your Internet speed (in the Mbit/s.) multiplied by 1024 Kbp/s. and divided by 8

For example: 3 Mbit \* 1024 Kbp / 8 = 384 Kbytes/s. - the maximum download speed using this Internet connection.

In free mode, however, the maximum file download is approximately 55-60 Kbytes/s.

What should I do if my download keeps failing?

Begin the download again using a new premium link. Clear your browser’s cache and cookies and try again. Try another browser (the latest version). Check your internet connection. Check your antivirus, adblock or firewall.

You can also try using a download manager (for example JDownloader). Note that you can only resume downloading a file from the point where the download failed if you are a Turbo (premium) user.

What download manager I can use?

You can use any popular download manager: JDownloader, Download Master, Internet Download Manager, Mipony, Folx (for users of Mac) etc. You can download these programs from their official sites. Note that you can only resume downloading a file from the point where the download failed if you are a Turbo (premium) user.

Can I search for particular files on Hitfile.com?

No. We care about our users’ privacy. Only the user who uploaded a file to Hitfile.com receives the download link, and it is up to them to decide who will have access to this file. So, you only have access to a file if you have the full link.

Are you responsible for the files I download?

Our file storage has nothing to do with the files which are downloaded by our users. We only provide the ability to store files and download them in free and Turbo (premium) mode. We recommend that you follow a few basic recommendations when downloading files: 1. Pay attention to what files you download and the file format of the downloaded file. For example, if you are downloading a movie file, then it is obvious that it should be in .avi, .mpg, etc. format. If, for example, a movie file is in .exe format, possibly this is a dangerous file. This does not of course include cases where the author of the file explains why it is in a particular format. 2. Only download files using links provided by websites which you trust. 3. Keep your antivirus software up to date. 4. For further instructions on file usage, consult the site where you found the link. In addition, the author of the file bears sole responsibility for its contents.

How much may I download from Hitfile.com?

The total size of downloads is restricted by your provider’s settings and your user status on Hitfile.com. If you are a free user, you may download about 5 Gb a day if downloading continually, but note that free account speed is limited. All users who have Turbo Access may enjoy the maximum download speed possible and download up to 40 Gb a day, 600 Gb per month.

I followed a link for file download and received a 'File was not found' message. Why is this?

A 'File was not found' message means that the file you are attempting to access has been removed from our server. There may be several reasons for this: - the file has been deleted by the user who uploaded it; - a copyright violation; - storage time expiration.

I have received a message saying 'You have reached the limit of connections from your IP range, please try downloading again after ... '. What do I do to download the file?

Our service aims to provide quality service to all users from all regions worldwide independent of file size, of download time, or of the user’s browser or other settings. To do this, we use Dynamic Download Splitting which helps us provide equal download opportunities to all free users irrespective of the file size. Turbo (premium) users have priority in download speed; other users are placed in a queue if they have same IP address: first come first served. The time you have to wait in line (the time specified in the message you receive from the Service) depends on several different factors: the popularity of the file, the load on the Hitfile.com server in your net zone, the time of day, etc., but the main factor is the file size. The bigger the file you downloaded last time, before requesting the latest file from the same IP, the longer you will have to wait. To reduce your waiting time, we recommend downloading small files first. You can also change your IP and try downloading the file again, since it is your particular IP that reaches the connection limit.

I have received a message from your service stating that I am downloading a file at the moment or that I have reached my download limit, when I have not been downloading anything! What could be the reason for that?

Our service checks your IP to keep download records. If you receive this message while in fact you have not been downloading anything, it means that you are using a proxy employed by a lot of users simultaneously. You may not be using a proxy for your computer, but your provider may be employing a client’s transparent proxy. If you have access to your network settings, quit your proxy. If you cannot do that, the only way out is to buy a Turbo (premium) Account. Turbo (premium) Users are recognized by their cookies, not by their IPs. Unfortunately, we cannot cancel all IP checks, otherwise we would have to shut down the service because of uncontrolled downloads. We hope for your understanding.

I do not have Turbo (premium) access yet

What is Turbo (premium) access? What advantages will it give me?

This is paid access to expanded functionality from our service, such as:

\- download without any time delays;

\- high-speed file download;

\- the ability to resume aborted downloads (including using download managers);

\- download by direct link;

\- download in several streams;

\- absence of advertising;

\- longer storage time for files, and other advantages.

After payment, Turbo (premium) access will be available in your account provided that you are registered and that you were signed into your account when you paid for it.

Or, if you make payment without being signed in or as a guest, that means you will receive a Turbo (premium) code. Turbo (premium) code - an alphanumeric code that looks something like 'x12yzw34', including no characters except letters and numbers. You will your receive Turbo (premium) code as soon as you have paid successfully, and you can activate it to download files.

What download speed will I get if I become a Turbo (premium) user?

Download speed for Turbo (premium) users can reach 1 Gbit/sec., if your connection allows it.

How much can I download if I have Turbo (premium) access?

All users who have Turbo (premium) access may enjoy the maximum download speed possible and download up to 40 Gb a day and up to 600 Gb per month.

How can I buy Turbo (premium) access?

To get Turbo (premium) access, you need to follow a few simple steps:

1\. Go to the payment page: [https://hitfile.net/premium](https://hitfile.net/premium)

2\. Choose a membership type;

3\. Select a payment method;

4\. Select 'Recommended options', if necessary;

5\. Enter your email if you are paying as a guest;

6\. Press the 'Pay now' button;

7\. Specify the necessary data for payment and follow the instructions to complete your payment.

If you pay as a guest or without being signed into your account, you will receive a Turbo (premium) code. If you are registered and signed in when you pay for it, Turbo (premium) access will be available in your account.

What should I do if I do not receive my Turbo (premium) code/access after I have paid?

Do not worry; you are bound to receive your Turbo (premium) code/access if you have paid for it. First, check your email or phone for incoming messages. In your email, be sure to check the 'Spam' folder. You also need to make sure that the payment was withdrawn from your account. To confirm this, it will be helpful if you can provide details of your payment.

If you have not received a Turbo (premium) code or Turbo (premium) access is not available in your account, contact our support desk. In this case, take care to select the necessary department and specify all necessary information in your request. This could be your email or phone number and information about how/when and for how many days you have paid for Turbo (premium) access. You should also include detail about your payment, and copy in your request the full contents of mail or SMS messages you received after payment. Alternatively, take a screenshot.

Your exact and full data will help us solve the problem quicker.

Why have I had a message saying I’ve reached the purchase limit on the site/on my phone?

For security reasons, you cannot get Turbo (premium) access more than twice using the same payment data within 24 hours.

Therefore, we advise you to buy Turbo (premium) access for a longer period at once. Besides, buying Turbo (premium) access for a longer term saves you money.

I can't pay using my card: it is rejected. What should I do?

Perhaps there is a problem with your card. The payment system doesn't trust your card, or else your bank. Try using a card from another bank or ask your bank for support. You can also try using another method of payment, or use the service provided by our resellers: [https://turbobit.net/turbo/reseller2](https://turbobit.net/turbo/reseller2)

All possible methods for getting Turbo (premium) access are listed on this page: [https://hitfile.net/premium](https://hitfile.net/premium)

I already have Turbo (premium) access

How can I use my Turbo (premium) code?

To download a file using a Turbo (premium) code, you need to follow a few simple steps:

1\. Go to the download page and click on the 'High Speed Download' button;

2\. You will see the payment page. Scroll to the bottom. Enter your Turbo (premium) code (received after payment) in 'Enter code here' field and press the 'Activate a premium code' button;

3\. Your Turbo (premium) code will be processed. After that, you will receive message about your premium period together with your download link;

4\. Click on the download link for your file and you will be moved to the final download page where you can save your file.

Note:

If you have paid for and received your Turbo (premium) code, but nothing happens when you enter it and the Turbo (premium) code does not respond to your actions, try clearing your browser’s cache and cookies and activating the code again. Try using another browser (the latest version).

I have a Turbo (premium) code, but your service does not recognize me. What is wrong?

If you have paid for and received your Turbo (premium) code, but nothing happens when you enter it and the Turbo (premium) code does not respond to your actions, try clearing your browser’s cache and cookies and activating the code again. Try using another browser (the latest version). Check your browser settings: cookies need to be enabled. Cookies are necessary for users working through proxy servers. If possible, try downloading the file using a different Internet connection.

Note:

Your Turbo (premium) code is not the password from your account. The Turbo (premium) code can be used only for fast file download. To get Turbo (premium) access in your account (for example to use the user name and password with a download manager), you need to sign up and activate your Turbo (premium) code in your account.

How do I register an account and activate my Turbo (premium) code in it?

For ease of use, security, and to avoid having to enter your Turbo (premium) code every time you want to download a file, you can register an account and activate your Turbo (premium) code in it. After that, all you will need to do to access fast file download will be to remain in your account. Your Turbo (premium) code will be bound to your account, and you will not need to activate the code every time you download a file.

Note: Use of some download managers (for example JDownloader) requires the user name and password from your Turbo (premium) account.

To register your account and activate your Turbo (premium) code in it, you need to follow a few simple steps:

1\. Go to the registration page at [https://hitfile.net/reg](https://hitfile.net/reg), specify your user name (email), invent a secure password, agree to the terms of our service and press the 'Sign up' button;

2\. After you have signed up successfully, you will be automatically signed into our website. Save your account password in a safe place;

3\. Go to the payment page at [https://hitfile.net/premium](https://hitfile.net/premium), go to the bottom of this page, enter your Turbo (premium) code (which you received after payment) in the 'Enter code here' field and press 'Activate a premium code'. Your Turbo (premium) code will be processed and you will see a message about it;

4\. Refresh the page. After that, at the top of account you will see that Turbo (premium) access is enabled in your account. Now, if you go to the download page for any file, you will receive a direct link for downloading this file.

How can I download files using Download Master?

1\. To download files using Download Master you need to have Turbo (premium) access on our website and to install the current version of Download Master on your computer:

\- You can purchase Turbo (premium) access on this page: [https://hitfile.net/premium](https://hitfile.net/premium)

\- You can find instructions about signing up for a Turbo (premium) account in our FAQ, under the title 'How do I register an account and activate my Turbo (premium) code in it?';

\- You can download the current version of Download Master from the program’s official web page.

2\. Activate your Turbo (premium) code or log in to your Turbo (premium) account, then go to the download page for any file and copy the direct link by right-clicking on 'Download file' or clicking on 'Direct link for download-accelerators and remote upload to other sites' and copying the link.

3\. Open Download Master and press the 'Add upload' button. In the window that opens, enter the link you copied earlier and press the 'Start download' button.

In addition, Download Master can automatically 'grab' links which have been copied to the clipboard.

How can I download files using of JDownloader?

1\. To download files using JDownloader you need to have Turbo (premium) access on our website and to install the current version of JDownloader on your computer:

\- You can purchase Turbo (premium) access on this page: [https://hitfile.net/premium](https://hitfile.net/premium)

\- You can find instructions about signing up for a Turbo (premium) account in our FAQ, under the title 'How do I register an account and activate my Turbo (premium) code in it?';

\- You can download the current version of JDownloader from the program’s official website.

2\. Launch JDownloader and go to the 'Account Manager' section in the 'Settings' tab.

3\. Add your Turbo (premium) account, and specify your account’s user name and password.

4\. Go to the 'LinkGrabber' tab, press the 'Add New Links' button and add links to the files which you want to download.

5\. Your links will be automatically processed by JDownloader and will receive 'online' status.

6\. Press the 'Start Downloads' button and begin downloading your files.

In addition, JDownloader can automatically 'grab' links which have been copied to the clipboard.

I have received a message saying 'Error! Too many attempts for this access code'. What shall I do?

To use a Turbo (premium) code, you should not enter it a large number of times or the code will be locked.

This limit is needed to protect against unauthorized and repeated use of Turbo (premium) codes. Write to our support desk, having first selected the necessary department to unblock your code.

To ensure this problem does not recur, you can do the following:

1\. You can register an account or sign into your account if you are already registered, and activate your Turbo (premium) code in it. After that, for fast file download, you will only need to remain in your account. Your Turbo (premium) code will be bound to your account and you will not need to activate the code every time you download a file.

2\. If you don't have an account, then you can register one on this page: [https://hitfile.net/reg](https://hitfile.net/reg)

If you don't want to register, just enter your Turbo (premium) code once before downloading a file and your browser will remember it. (You will need to be using a recent version of your browser.)

I have received a message saying 'There have been too many failed password entry attempts from your IP address.Please try again in an hour'

To use your Turbo (premium) code, do not enter it a large number of times or the code will be locked. This limit is needed to protect against the unauthorized and repeated use of Turbo (premium) codes.

You have received this message because you activated your Turbo (premium) code more than ten times in a row. You will need to wait about an hour before you can continue using this Turbo (premium) code.

Why have I received a message saying 'You have reached the limit of premium downloads'

To make sure that all users get high download speeds and low delays and also to stop sharing of Turbo (premium) access, we’ve limited the number of files that can be downloaded in premium mode to 250 per day – which should be enough for most users.

[https://hitfile.net/rules](https://hitfile.net/rules) (IV. PREMIUM ACCOUNT SERVICES).