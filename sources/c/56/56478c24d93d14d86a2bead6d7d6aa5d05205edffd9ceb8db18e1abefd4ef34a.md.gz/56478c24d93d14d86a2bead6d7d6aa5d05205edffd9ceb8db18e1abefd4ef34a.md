# Quick start

You can go from nothing to a shell in your own cloud machine with two commands. It needs Node.js 22 or later. 

```bash
command -v quivvo >/dev/null || npm i -g quivvo@latest
quivvo sh
```

That signs you in with a code in the browser, creates a machine called `dev`, and opens a shell in it. New accounts get $5 of credit, with no card needed.


You can try it without installing, with `npx quivvo@latest sh`. That leaves nothing on your PATH, so every later command has to start with `npx quivvo@latest` too.

If you're an AI agent, follow [the setup runbook](https://tryquivvo.com/setup.md) instead. With no terminal, `quivvo sh` opens no shell and waits for nobody: it tells you the next command to run.

## How do I give my coding agent machines?

Add the hosted MCP server, and the agent creates and drives machines itself. It signs in through your browser the first time, with no key to paste:

```bash
claude mcp add --transport http quivvo https://tryquivvo.com/api/mcp
```

In Cursor or VS Code it's one click: [add to Cursor](cursor://anysphere.cursor-deeplink/mcp/install?name=quivvo&config=eyJ1cmwiOiJodHRwczovL3RyeXF1aXZ2by5jb20vYXBpL21jcCJ9), or [install in VS Code](vscode:mcp/install?%7B%22name%22%3A%22quivvo%22%2C%22type%22%3A%22http%22%2C%22url%22%3A%22https%3A%2F%2Ftryquivvo.com%2Fapi%2Fmcp%22%7D). Codex and the rest are in [MCP server](https://tryquivvo.com/docs/mcp).

## How do I run commands from my laptop?

```bash
quivvo exec dev -- uname -a
```

`exec` prints the command's output as it happens and exits with its exit code.

A command that waits for its result stops at 280 seconds. For anything longer, or anything that might outlast a tool's own timeout, start a background job:

```bash
JOB=$(quivvo exec dev --background --timeout 1800 -- "npm test")
quivvo jobs wait dev "$JOB" --timeout 100
quivvo jobs logs dev "$JOB" --tail 50
```

`jobs wait` exits 124 when the wait runs out and the job is still going, so run it again. See [recipes](https://tryquivvo.com/docs/recipes) for more.

## How do I copy files in and out?

```bash
quivvo push ./app dev
quivvo cp dev:/data/home/report.txt .
```

`push` sends a directory the way git sees it: tracked and new files, but nothing ignored, no `.git`, and no `.env`. `cp` copies anything either way, and sends everything you point it at.

Keep work under `/data`: that's the disk that stays, and your home directory is `/data/home`.

## How do I reach a server inside the machine?

```bash
quivvo port publish dev 3000
```

That prints a public HTTPS URL for port 3000. Add `--private` for a link with a token, or use `quivvo port-forward dev 3000` for a tunnel to localhost. A machine's URL serves one port, the last one you published, and answers only while the machine runs.

## How do I stop paying for it?

```bash
quivvo suspend dev
```

A suspended machine only pays for disk. Suspend keeps memory and running processes when it can, and otherwise stops the machine, which keeps the disk but not memory or processes. The command tells you which one happened. Machines also suspend themselves after 30 idle minutes by default, or 15 on the Free plan, and the next command wakes them.

When you're done for good, `quivvo rm dev` deletes the machine and its disk.

## Next

- Let an agent [sign itself up](https://tryquivvo.com/docs/agents).
- Script everything from TypeScript or Python with the [SDKs](https://tryquivvo.com/docs/sdks), or from anything with the [REST API](https://tryquivvo.com/docs/api).
