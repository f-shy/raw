Project disk storage for projects with compute allocations on Arrhenius GPU and/or Arrhenius CPU.

Using the Lustre parallel filesystem, it is designed for fast access from Arrhenius GPU and Arrhenius CPU. File contents are stored on spinning disks. The total size of Arrhenius Disk is 25 PB. There is no backup of Arrhenius Disk.

##### NAISS Medium 2026

To apply, you must be a scientist in Swedish academia, at least at the level of assistant professor.

See [further information](https://user.naiss.se/allocations/medium).

[Go to NAISS Medium 2026](https://supr.naiss.se/round/2026medium/)

##### NAISS Small 2026

To apply, you must be a scientist in Swedish academia, at least at the level of Doctoral student. Doctoral students must provide the name and affiliation of their main supervisor in the proposal.

See [further information](https://user.naiss.se/allocations/small).

[Go to NAISS Small 2026](https://supr.naiss.se/round/2026small/)

##### NAISS Large Spring 2027

To apply, you must be at least an assistant professor at an eligible Swedish institution. NAISS is financed by Swedish tax payers with the objective to strengthen science and research in Sweden. To apply for these resources, you must therefore hold an appointment of at least 60 percent at a Swedish university or research institution recognized by the Swedish Research Council and have been the Principal Investigator of a NAISS Medium project or similar.

This round will open in March 2027.

[Go to NAISS Large Spring 2027](https://supr.naiss.se/round/spring2027large/)
