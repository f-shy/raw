# Pix

## Pix recebe registro de marca de alto renome

O Pix foi reconhecido pelo INPI como marca de alto renome, a primeira de um órgão público a obter a distinção. A medida reforça a proteção contra usos indevidos do nome.

Saiba mais >>

## O que é o Pix?

Pix é um sistema de pagamento instantâneo criado pelo Banco Central, que permite transferir dinheiro entre contas em segundos, a qualquer hora e dia. É rápido, prático e seguro e pode ser usado a partir de contas corrente, poupança ou pré-pagas.

Saiba mais sobre o Pix

## Vantagens do Pix

#### Rápido

Dinheiro cai na conta em poucos segundos

#### Disponível

24 horas por dia, 7 dias da semana

#### Fácil

Simples e intuitivo, focado no usuário

#### Barato

Gratuito para pessoa física e custo baixo para empresa

#### Seguro

Conta com mecanismos robustos de segurança

#### Aberto

Oferecido por vários tipos de instituições

#### Versátil

Usado para diferentes situações e tipos de pagamento

#### Integrado

Facilita conciliação, automatização e integração de sistemas

  


## Pix em números

Os dados apresentados são relativos ao número de usuários que já fizeram Pix e às estatísticas de quantidade e valor de transações Pix

+150 milhões

de pessoas físicas usaram o Pix em setembro de 2026

+7,8 bilhões

transações realizadas em setembro de 2026

+R$3,8 trilhões

volume em setembro de 2026 > 3 PIBs mensais (Produto Interno Bruto)

318,1 milhões

recorde de transações em um único dia\*

\*Recorde de 318.116.744 transações em 04/09/2026

Veja mais estatísticas do Pix

## Pix em vídeos

**Como funciona o Pix Automático e o que ele muda no dia a dia das empresas e pessoas?** LiveBC #43

**Pix Automático, débito ou cartão de crédito: qual o melhor para sua conta?** BC te Explica #154

**7 Dicas para Lidar com Golpes Envolvendo Pix** BC te Explica #1

**Mecanismo Especial de Devolução do Pix (MED)** BC te Explica #28

**Botão de Emergência do Pix vai te Ajudar a não Cair em Golpes!** BC te Explica #155

**Como receber pagamentos com Pix Automático?** Como é que uma empresa pode passar a receber pagamentos por Pix Automático?

**Como funciona o Pix Automático para pagar contas?** O Pix Automático está chegando para facilitar a sua vida!

**Conexão Pix 3ª edição.** Confira como foi o evento em que o BC apresentou o Pix Automático com participação de empresas e especialistas do setor.

**BC te Explica #131 - O que são o Pix automático e o agendamento recorrente?** Agende pagamentos e transferências com praticidade.

chevron\_left

chevron\_right

Veja mais vídeos sobre o Pix

---

## A trajetória do Pix

2014 – Nasce uma ideia

Primeira política do BC sobre pagamentos instantâneos

- Fórum sobre arranjos e IPs  
 - GT para pagamentos instantâneos  
 - Criação do Fórum Pix  
 - Lançamento da marca Pix   
 - Instituição do SPI   
 - Regulamento do Pix

2016-2020 – Elaboração

16/11/2020 – Lançamento

- Pix Saque e Pix Troco  
 - Bloqueio cautelar  
 - Mecanismo Especial de Devolução (MED)  
 - Open Finance: iniciação de pagamento via Pix

2021 - Mais produtos e segurança

2022 - Tecnologia a favor do cidadão

- Limites noturnos para maior segurança  
 - QR Code dinâmico com mais funcionalidades

- Maior integração com Open Finance

2023 - Sinergia para gerar impacto

2024 - Experiência simplificada

- Jornada sem redirecionamento (Pix + Open Finance)  
 - Pix Agendado

- Pix Automático  
 - Pix por aproximação

2025 - Usuário em primeiro lugar