Phone full again? Laptop running out of space? Blomp gives you 40 GB of free cloud storage, and up to 400 GB when the friends you invite join and stay active. Your photos, videos and files stay safe in the cloud for as long as you want them.

If your phone or computer is lost or breaks, your files are still there. Blomp keeps three copies of your data in three availability zones.

Use Blomp in any web browser on Windows, Mac, Linux, iPhone or Android. Upload lots of files at once, make folders, rename, preview and download whenever you like.

Prefer your own tools? Blomp speaks the S3 and OpenStack Swift standards, so apps like rclone, Cyberduck, Mountain Duck and Duplicati can sync, back up and even mount your storage as a drive.

Store any kind of file: photos, videos, music, documents, PDFs, spreadsheets and presentations.

Blomp is fair and private. We don’t sell, share or analyse your data, and there are no ads.

Need more room? Paid plans start at 500 GB for $11.88 a year, with 2 TB, 10 TB and much bigger plans for apps and businesses.

Blomp

# Get up to 400 GB of cloud storage free

Keep your photos, videos and files safe, and reach them from the web, your phone or any S3 app.

[Sign up free](https://dashboard.blomp.com/register)[Log in](https://dashboard.blomp.com/)

Want the technical details? [How Blomp storage works](https://www.blomp.com/cloud-storage/)

## Free and Paid Plans

Start free, and upgrade only when you need more room.

## 40 – 400 GB

### Free

- 40 GB of Storage
- Up to 400 GB
- Add 40 GB for every friend who joins and stays active

[Sign Up](https://dashboard.blomp.com/register)

## 500 GB

### $11.88/Year

- 500 GB of Storage
- Everything in the 40 – 400 GB Plan
- No Yearly Logins Required

[Sign Up](https://dashboard.blomp.com/register)

## 2 TB

### $2.99/Month

- 2 TB of Storage
- Everything in the 500 GB Plan
- No Yearly Logins Required

[Sign Up](https://dashboard.blomp.com/register)

## 10 TB

### $9.99/Month

- 10 TB of Storage
- Everything in the 2 TB Plan
- No Yearly Logins Required

[Sign Up](https://dashboard.blomp.com/register)

Need more than 10 TB? [See plans up to 500 TB](https://www.blomp.com/cloud-storage/)

## Why Blomp?

40 GB free

to start, up to 400 GB as friends join

S3 + Swift

open standards, use the tools you like

16 apps

tested with Blomp, with how-to guides

## Use Blomp your way

### In your browser

Upload, organise, preview and share your files from any computer, phone or tablet. Nothing to install.

[Open Blomp](https://dashboard.blomp.com/)

### With the apps you know

Blomp works with S3 and OpenStack Swift apps like rclone, Cyberduck and Duplicati on Windows, macOS, Linux and Android.

See the apps we test

### New Blomp apps

Our new desktop and mobile apps are on the way. Until then, the web dashboard and the apps above have you covered.

[Questions? Ask on the support forum](https://support.blomp.com/)

## Works with the apps you already use

Blomp speaks S3 and OpenStack Swift, so these apps work with your Blomp storage. Make a key on the [S3 keys page](https://dashboard.blomp.com/dashboard/s3-keys) of your dashboard, then follow the step-by-step guide on the [Blomp support forum](https://support.blomp.com/).

### Blomp Drive

Windows · macOS · Linux · Android

Blomp's own app: your Blomp storage as a drive on your computer, plus the Blomp app for your phone.

[Get Blomp Drive: How to: Blomp Drive on Windows, Mac, Linux and your phone (downloads, videos and troubleshooting)](https://support.blomp.com/viewtopic.php?t=6575)

Sync and transfer

### [rclone](https://rclone.org/)

Windows · macOS · Linux — S3 or Swift

Sync, copy and mount your Blomp files from the command line.

[How-to guide: How to: rclone with Blomp (S3 keys, plus the Swift way) →](https://support.blomp.com/viewtopic.php?t=6479)

Backup

### [Duplicati](https://duplicati.com/)

Windows · macOS · Linux — S3 or Swift

Scheduled, encrypted backups of your computer to Blomp.

[How-to guide: How to: Duplicati backups to Blomp (S3 or OpenStack Swift) →](https://support.blomp.com/viewtopic.php?t=6481)

File managers

### [Cyberduck](https://cyberduck.io/)

Windows · macOS — S3 or Swift

Drag-and-drop file browser for your Blomp storage.

[How-to guide: How to: Cyberduck and Mountain Duck with Blomp (S3 or Swift) →](https://support.blomp.com/viewtopic.php?t=6480)

File managers

### [WinSCP](https://winscp.net/)

Windows — S3

Two-panel file manager for Windows, with scripting.

Use path-style URLs and region us-east-1.

[How-to guide: How to: WinSCP, muCommander and Midnight Commander with Blomp →](https://support.blomp.com/viewtopic.php?t=6488)

File managers

### [muCommander](https://www.mucommander.com/)

Windows · macOS · Linux — S3

Cross-platform two-panel file manager.

[How-to guide: How to: WinSCP, muCommander and Midnight Commander with Blomp →](https://support.blomp.com/viewtopic.php?t=6488)

File managers

### [Midnight Commander](https://midnight-commander.org/)

Linux — S3

The classic terminal file manager.

Needs Blomp's s3+ helper (in the guide).

[How-to guide: How to: WinSCP, muCommander and Midnight Commander with Blomp →](https://support.blomp.com/viewtopic.php?t=6488)

Use Blomp as a drive

### [Mountain Duck](https://mountainduck.io/)

Windows · macOS — S3 or Swift

Blomp as a drive letter or Finder volume.

[How-to guide: How to: Cyberduck and Mountain Duck with Blomp (S3 or Swift) →](https://support.blomp.com/viewtopic.php?t=6480)

Use Blomp as a drive

### [GeeseFS](https://github.com/yandex-cloud/geesefs)

Linux — S3

Mount Blomp as a fast folder on Linux.

[How-to guide: How to: mount Blomp as a folder on Linux (GeeseFS, rclone mount, GNOME Files) →](https://support.blomp.com/viewtopic.php?t=6485)

Use Blomp as a drive

### [JuiceFS](https://juicefs.com/)

Linux — S3

A real Linux filesystem that keeps its data on Blomp.

[How-to guide: How to: JuiceFS on Blomp (a Linux filesystem on your S3 storage) →](https://support.blomp.com/viewtopic.php?t=6854)

Servers and self-hosting

### [Litestream](https://litestream.io/)

Linux · Server — S3

Continuous SQLite database backups to Blomp.

[How-to guide: How to: server backups to Blomp with Litestream (SQLite) and pgBackRest (PostgreSQL) →](https://support.blomp.com/viewtopic.php?t=6484)

Servers and self-hosting

### [pgBackRest](https://pgbackrest.org/)

Linux · Server — S3

PostgreSQL backups and point-in-time restore on Blomp.

[How-to guide: How to: server backups to Blomp with Litestream (SQLite) and pgBackRest (PostgreSQL) →](https://support.blomp.com/viewtopic.php?t=6484)

Servers and self-hosting

### [OpenList](https://github.com/OpenListTeam/OpenList)

Server · Web — S3

Your own web file server and WebDAV, stored on Blomp.

[How-to guide: How to: your own file server on Blomp (OpenList, Cloudreve, Filestash, SFTPGo) →](https://support.blomp.com/viewtopic.php?t=6486)

Servers and self-hosting

### [Cloudreve](https://cloudreve.org/)

Server · Web — S3

Self-hosted cloud drive with Blomp as the storage.

[How-to guide: How to: your own file server on Blomp (OpenList, Cloudreve, Filestash, SFTPGo) →](https://support.blomp.com/viewtopic.php?t=6486)

Servers and self-hosting

### [Filestash](https://www.filestash.app/)

Server · Web — S3

Browser-based file manager for your Blomp files.

[How-to guide: How to: your own file server on Blomp (OpenList, Cloudreve, Filestash, SFTPGo) →](https://support.blomp.com/viewtopic.php?t=6486)

Servers and self-hosting

### [SFTPGo](https://sftpgo.com/)

Server · Web — S3

SFTP, FTP and WebDAV server backed by Blomp.

[How-to guide: How to: your own file server on Blomp (OpenList, Cloudreve, Filestash, SFTPGo) →](https://support.blomp.com/viewtopic.php?t=6486)

Phones

### [RSAF + MaterialFiles](https://github.com/chenxiaolong/RSAF)

Android — S3

Blomp in the Android file picker and a full file manager.

[How-to guide: How to: Blomp on Android with MaterialFiles + RSAF →](https://support.blomp.com/viewtopic.php?t=6487)

Everything else

### Any S3-compatible app

Windows · macOS · Linux · Android · iOS · Server — S3

AWS CLI, backup tools and more: the settings that work.

[How-to guide: Blomp S3 settings for any app, plus troubleshooting →](https://support.blomp.com/viewtopic.php?t=6478)

Tested by the Blomp team. Using something else? Ask on the [support forum](https://support.blomp.com/).

## [**Blomp: free cloud storage for your photos, videos and files**](https://www.blomp.com/)

Blomp is a safe home for your family memories and important files. Start with 40 GB free and grow to 400 GB by inviting friends.

Use Blomp in your web browser, or with the S3 and Swift apps you already know, like rclone and Cyberduck. Need more room? Paid plans start at 500 GB and go far beyond 10 TB.

Blomp © 2026

**[Storage plans for apps](https://www.blomp.com/cloud-storage/)**

**[Blog](https://www.blomp.com/blog/)**

**[Support forum](https://support.blomp.com/)**

**[Terms and Conditions](https://www.blomp.com/terms-and-conditions/)**

**[Privacy Policy](https://www.blomp.com/privacy-policy/)**
