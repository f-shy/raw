HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Wed, 25 Nov 2026 13:03:57 GMT
content-type: application/json; charset=utf-8
content-length: 530
access-control-allow-origin: *
cf-placement: [redacted]
access-control-expose-headers: *, x-web-egress, x-web-form, x-web-provider, x-web-account, x-web-body, x-web-snapshot-at, x-web-cache, x-web-headers, x-web-origin-status, x-web-provider-origin-status, x-web-final-url, x-web-providers, x-web-corpus, x-web-store, allow, retry-after, location, memento-datetime
x-web-account: firecrawl-as
x-web-body: rewritten-by=firecrawl
x-web-cache: miss
x-web-corpus: W/"f5c90cd09c27c16c2a858721ee4afdebeb10178b7168a5c0992151b871991e72"
x-web-egress: egress=provider:firecrawl tried=cf-fetch+provider:firecrawl memo=refused(challenge) escalated=challenge escalation=provider(firecrawl)
x-web-final-url: https://pan.t-satoru.top/api/fs/list
x-web-form: path-scheme
x-web-headers: provider
x-web-origin-status: 403
x-web-provider: firecrawl
x-web-provider-origin-status: 200
report-to: {"group":"cf-nel","max_age":604800,"endpoints":[{"url":"https://a.nel.cloudflare.com/report/v4?s=EtoxZOty8vkegudSjMvcR8CaWKOkI6e45uU7M9kR%2BzDruAgU2j6WpsisWr5TSZJYJ%2FHo%2FDttl%2B5hQeXMuPvg0msLqot9832iofxqSgxYyK1u1BzZKp37aGMLHs7JVdEslvLiGLgnG1ko"}]}
nel: {"report_to":"cf-nel","success_fraction":0.0,"max_age":604800}
server: cloudflare
cf-ray: a600db259ce03fcc-[redacted]
alt-svc: h3=":443"; ma=86400


{"code":200,"message":"success","data":{"content":[{"name":"piv","size":0,"is_dir":true,"modified":"2025-06-25T03:18:30.646747644Z","created":"2025-06-25T03:18:30.646747644Z","sign":"","thumb":"","type":1,"hashinfo":"null","hash_info":null},{"name":"s3b","size":0,"is_dir":true,"modified":"2026-08-25T05:05:00.161611134Z","created":"2026-08-25T05:05:00.161611134Z","sign":"","thumb":"","type":1,"hashinfo":"null","hash_info":null}],"total":2,"readme":"","header":"","write":true,"write_content_bypass":false,"provider":"unknown"}}