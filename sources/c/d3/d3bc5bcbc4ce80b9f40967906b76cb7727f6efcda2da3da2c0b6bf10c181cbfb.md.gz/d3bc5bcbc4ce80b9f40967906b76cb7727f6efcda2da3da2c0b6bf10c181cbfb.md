Learn more about FEEMOO CLOUD瞭解更多飛貓盤瞭解更多飛貓盤Top 10 years old brand rich interactive play Leading Darren promotion platform上線10年老品牌豐富的互動玩法領先的達人推廣平臺Fast download speedExtreme acceleration up to 50MB/S下載速度快極致加速高達50MB/SQuick decompressionFile no need to download極速解壓文件文件無需下載在線處理Preview documents onlineNo need to download to view immediately文件在線預覽無需下載馬上查看FeemooZIP?图形

会员

动态

文件

合集

收藏

客户端

取件

English

简体中文

繁體中文

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vip-newTb-new.png)开通会员

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vip-bgTwo-new.png)

开通后立享 10+ 会员特权

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vip-oneNew-new.png)

下载额度
500 次/天

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vip-twoNew-new.png)

下载加速
享极致加速

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vip-threeNew-new.png)

云盘空间
2000 G

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vip-fourNew-new.png)

云盘权益
6项在线功能

开通不限时长Ultra

登 录注 册

提示

提示

提示

会员

动态

文件

合集

收藏

0

客户端

取件

账号权益

开通会员

下载额度

福利点

下载加速

0%

/

主题：浅色

自动

浅色

深色

帮助中心

账号设置

退出登录

提示

提示

开通会员福利社

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vipc-bgAll.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/user-nopic2.png)

未登录![](<Base64-Image-Removed>)

不限时长会员 10+ 权益

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/m_icon5/3_light.png)

加速下载额度

300次/天

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/m_icon5/4_light.png)

下载加速

享极致加速

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/m_icon5/5_light.png)

云盘空间

1000G

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/m_icon5/6_light.png)

在线云解压

极速解压

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/m_icon5/7_light.png)

云盘权益

6项在线功能

查看全部权益

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/Maskgroup_left.png)![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/Maskgroup_middle.png)![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/Maskgroup_right.png)12周年限量发售12周年限量发售不限时长会员￥388￥899立省￥511![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/selected_right_icon.png)年度会员￥178￥360立省￥182连续包月￥20￥30立省￥10月度会员￥30

购买不限时长会员，尊享Feemoo特权

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon_pay_23.png)支付宝

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon_pay_2_11.png)微信支付

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon_pay_AlipayHK.png)AlipayHK

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon_pay_bank.png)银行卡支付

使用优惠码

实付:¥388已优惠511元！

阅读并同意 [《Feemoo会员服务协议》](https://www.feemoo.com/askdetail/124)

开通会员

![](https://ugc.app-static.com/static/images/user-nopic2.png)

1\*\*\*\*\*\*2

开通了

不限时长会员

![](https://ugc.app-static.com/Public/web/img/webapp/fm2026/feemoo_avatar/feemoo-avatar-02.png)

s\*\*\*\*\*\*4

开通了

不限时长会员

![](https://ugc.app-static.com/Public/web/img/webapp/fm2026/feemoo_avatar/feemoo-avatar-02.png)

R\*\*\*\*x

开通了

不限时长会员

![](https://ugc.app-static.com/Public/web/img/webapp/fm2026/feemoo_avatar/feemoo-avatar-02.png)

L\*\*\*\*\*\*7

开通了

不限时长会员

![](https://ugc.app-static.com/Public/web/img/webapp/fm2026/feemoo_avatar/feemoo-avatar-02.png)

0\*\*\*\*\*\*5

开通了

不限时长会员

![](https://ugc.app-static.com/Public/web/img/webapp/fm2026/feemoo_avatar/feemoo-avatar-02.png)

T\*\*\*\*5

开通了

不限时长会员

![](https://ugc.app-static.com/Public/web/img/webapp/fm2026/feemoo_avatar/feemoo-avatar-13.png)

9\*\*\*\*\*\*1

开通了

不限时长会员

![](https://ugc.app-static.com/img_server/kind/attached/thumb/20201203/20201203210222_76604.jpg)

灵\*\*\*\*\*处

开通了

不限时长会员

![](https://ugc.app-static.com/img_server/kind/attached/thumb/20201209/20201209011514_51030.jpg)

M\*\*\*\*\*\*x

开通了

不限时长会员

![](https://ugc.app-static.com/Public/web/img/webapp/fm2026/feemoo_avatar/feemoo-avatar-13.png)

阿\*\*\*\*5

开通了

不限时长会员

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/icon-vipc-bgTop.png)

提示

提示

提示

提示

全部权益

会员权益

不限时长会员

年度会员

月度会员

非会员

下载权益

下载限速

不限速

高速下载

高速下载

不超过50KB/s

加速下载额度

300次/天

20次/天

10次/天

无额度

加速类型

极致加速

会员加速

会员加速

无加速

云转存\\*

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

云盘权益

云盘空间

1000G

200G

100G

10G

云解压

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

不支持

云看图

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

云阅读

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

回收站有效期

60天

30天

30天

10天

影音权益

云视频

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

云音乐

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

体验权益

会员去广告

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/select-active.png)

不支持

注：标有\*特权需消耗下载额度使用，剩余加速下载额度不足时，可消耗福利点使用。

暂无上传任务

严禁上传或分享反动、暴力、色情、违法及侵权内容的文件。

设置文件目录：

全部文件

添加文件

全部开始全部暂停全部取消

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/icon-up.png)

普通下载通道 · 极速下载中 0B/s

立即提速

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/icon-pc.png)

全新PC端，大文件下载更稳定

前往体验

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/file_default.png)暂无下载记录

有任务进行时请勿刷新网页

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/file_default.png)暂无解压记录

删除解压记录

上传

下载

解压

![](https://webimg.app-static.com/Public/web/img/webapp/fm2023/web4/icon-up.png)

会员极速下载中

提示

提示

提示

提示

等文件