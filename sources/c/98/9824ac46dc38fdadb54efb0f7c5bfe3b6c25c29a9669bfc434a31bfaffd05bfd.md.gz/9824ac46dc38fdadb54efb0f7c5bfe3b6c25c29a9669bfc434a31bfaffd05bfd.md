# Automatically delete Chat messages for your organization

*Supported editions for this feature: Frontline Plus; Business Plus; Enterprise Standard and Enterprise Plus; Education Standard and Education Plus; Enterprise Essentials and Enterprise Essentials Plus.* *[Compare your edition](https://knowledge.workspace.google.com/admin/getting-started/editions/compare-google-workspace-editions)*

You can control if and when messages sent through Google Chat are deleted automatically with Chat auto-deletion settings. This feature only applies to messages sent while conversation history is on.

You can enable separate auto-deletion policies for every kind of conversation: 1:1 direct messages, group messages, and space messages.

Messages with external organizations are only deleted according to the policy of the conversation creator. So conversations created by your organization will follow your deletion policies, while externally created conversations will not follow your policies.

## Google Chat auto-deletion & Google Vault

Chat auto-deletion policies and messages deleted as a result of them are subject to Chat and Google Vault retention rules.

If a Vault retention rule applies to a conversation with a Chat auto-deletion policy, messages will be deleted as follows:

- **Vault retention removes a message before the Chat auto-deletion period**—The message will be removed from a conversation and kept in Vault for 30 days due to the default retention rule. The purge process begins on day 30, and may take several days to complete depending on the number of messages being purged.
- **The Chat auto-deletion period comes before the Vault retention period**—The message will be removed from the conversation and kept in Vault for the remainder of the retention period or at minimum 30 days.
- **A user deletes a message before auto-deletion or Vault**—The message will be kept in Vault for the remainder of the retention period and for 30 days at least.

If no Vault retention rule applies to the message, messages auto-deleted are kept for 30 days after the auto-deletion policy or a user removes them from a conversation. The purge process begins on day 30, and may take several days to complete.

## Large spaces & Google Vault

A hold on an account prevents user data from being deleted. Holds can be placed on individual accounts or entire organizational units. You can use holds to prevent message data from being deleted (messages made with Chat history on).

However, this feature does not apply for messages made in extra-large spaces (spaces with over 50k users). Messages posted to extra-large spaces will be removed according to the space's retention policy; messages not posted to these spaces will be held, per usual. For scalability and performance reasons, it can be difficult to check the hold status of each user for every message sent. Plan how you operate your large spaces carefully.

To learn more, read, [Get started with holds in Google Vault](https://support.google.com/vault/answer/7664657).

## Manage Chat auto-deletion policy

Once you set your auto-deletion policy, all messages in relevant conversations older than the auto-deletion period will be deleted. Afterwards, all messages will be deleted gradually as they reach auto-deletion period lifetime.

### Turn auto-deletion on or off for 1:1 direct messages

**Before you begin:** If you need to set up a department or team for this setting, go to [Add an organizational unit](https://knowledge.workspace.google.com/admin/users/advanced/add-an-organizational-unit).

1. In the Google Admin console, go to Menu  and then  **Apps** and then **Google Workspace** and then **Google Chat**.

  [Go to Google Chat](https://admin.google.com/ac/appsettings/216932279217)

  Requires having the [Google Chat administrator privilege.](https://knowledge.workspace.google.com/admin/users/administrator-privilege-definitions#google-chat)
2. Click **Auto-deletion**.
3. Click **1:1 Direct messages**.
4. (Optional) To apply the setting to a department or team, at the side, select an **organizational unit**.
5. Check or uncheck the **Enable auto-deletion** box to turn automatic deletions on or off.
6. For **Number of days while message stays visible in 1:1 direct messages**, enter a number between 30 and 36500.
7. Click **Save.** Or, you might click **Override** for an organizational unit.

  To later restore the inherited value, click **Inherit**.

### Turn auto-deletion on or off for group direct messages

1. In the Google Admin console, go to Menu  and then  **Apps** and then **Google Workspace** and then **Google Chat**.

  [Go to Google Chat](https://admin.google.com/ac/appsettings/216932279217)

  Requires having the [Google Chat administrator privilege.](https://knowledge.workspace.google.com/admin/users/administrator-privilege-definitions#google-chat)
2. Click **Auto-deletion**.
3. Click **Group direct messages**.
4. Check or uncheck the **Enable auto-deletion** box to turn automatic deletions on or off.
5. For **Number of days while message stays visible in group messages**, enter a number between 30 and 36500.
6. Click **Save**.

### Turn auto-deletion on or off for messages in spaces

1. In the Google Admin console, go to Menu  and then  **Apps** and then **Google Workspace** and then **Google Chat**.

  [Go to Google Chat](https://admin.google.com/ac/appsettings/216932279217)

  Requires having the [Google Chat administrator privilege.](https://knowledge.workspace.google.com/admin/users/administrator-privilege-definitions#google-chat)
2. Click **Auto-deletion**.
3. Click **Spaces**.
4. Check or uncheck the **Enable auto-deletion** box to turn automatic deletions on or off.
5. For **Number of days while message stays visible in space messages**, enter a number between 30 and 36500.
6. Click **Save**.

## Additional information
