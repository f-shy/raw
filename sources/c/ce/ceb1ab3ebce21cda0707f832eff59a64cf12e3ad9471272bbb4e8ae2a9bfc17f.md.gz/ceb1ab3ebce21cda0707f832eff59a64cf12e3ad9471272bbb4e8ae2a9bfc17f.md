HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Wed, 25 Nov 2026 02:31:36 GMT
content-type: application/x-nzb
accept-ranges: bytes
access-control-allow-origin: *
age: 140
cache-control: private, no-cache
content-disposition: inline; filename="Linux Magazine #04 (2026).nzb"
expires: Mon, 12 Jul 2000 01:00:00 GMT
last-modified: Wed, 25 Nov 2026 02:29:15 GMT
server: cloudflare
vary: Accept-Encoding
access-control-expose-headers: *, x-web-egress, x-web-form, x-web-provider, x-web-account, x-web-body, x-web-snapshot-at, x-web-cache, x-web-headers, x-web-origin-status, x-web-provider-origin-status, x-web-final-url, x-web-providers, x-web-corpus, x-web-store, allow, retry-after, location, memento-datetime
nel: {"report_to":"cf-nel","success_fraction":0.0,"max_age":604800}
report-to: {"group":"cf-nel","max_age":604800,"endpoints":[{"url":"https://a.nel.cloudflare.com/report/v4?s=DjQHgq4A%2Fz2Ob8Lg4S0wF8GKET8dZmvM0Eyo4ibOkXBlWfukSfNKUzAP9BIyOgQcd3qCQB2fIFro7FTRxfLD%2BbsBGgJaSu%2FGA9ENu0co629XAKJYjh50uhp%2F1Z5pYjH48UF78C%2Fc%2FjU9nQ%3D%3D"}]}
x-web-corpus: W/"f5c90cd09c27c16c2a858721ee4afdebeb10178b7168a5c0992151b871991e72"
x-web-egress: egress=cf-fetch tried=cf-fetch identity=fixed tls=platform headers=partial dialFailureObservable=true responseFramingModified=true decoded=gzip redirects=followed(1),temporary
x-web-final-url: https://spotnzb.com/?page=getnzb&action=display&messageid=19XKJ8pokN4BLjUagNmQp@spot.net
x-web-form: query-url
cf-ray: [redacted]
alt-svc: h3=":443"; ma=86400


<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE nzb PUBLIC "-//newzBin//DTD NZB 1.0//EN" "http://www.newzbin.com/DTD/nzb/nzb-1.0.dtd">
<nzb xmlns="http://www.newzbin.com/DTD/2003/nzb"><head/><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[1/10] - &quot;L2oxorYDqSshfpZq4f7H5W.par2&quot; yEnc (1/1) 40428">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="40428" number="1">8336780830544a6480eed8c8a1432a7e@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[4/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol001+02.par2&quot; yEnc (1/1) 99548">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="99548" number="1">266d1633a6e14c4aa3e0a458b1de1116@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[3/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol000+01.par2&quot; yEnc (1/1) 49828">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="49828" number="1">2faa73ca3216483aa7778f087f9dceb4@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[5/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol003+04.par2&quot; yEnc (1/1) 158668">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="158668" number="1">1205c38c6bff404a80fb0b036d2e1f2a@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[6/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol007+08.par2&quot; yEnc (1/1) 236588">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="236588" number="1">0ec8e8bfb37f46afbaabab55bebef438@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[7/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol015+16.par2&quot; yEnc (1/1) 352108">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="352108" number="1">19252880566d4b629ffa311bc90b580a@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[8/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol031+32.par2&quot; yEnc (1/1) 542828">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="542828" number="1">0b4a4c3c951b4d8ab3a979a2f00232fd@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[10/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol127+73.par2&quot; yEnc (1/2) 968548">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="716800" number="1">12244a9add1c49bfa5389e3210ca94b6@ngPost</segment>
      <segment bytes="251748" number="2">9a99928bf9984aa8b742768def9fead5@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[9/10] - &quot;L2oxorYDqSshfpZq4f7H5W.vol063+64.par2&quot; yEnc (1/2) 883948">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="716800" number="1">a53cbe24b5b845548fef4244794fc5ce@ngPost</segment>
      <segment bytes="167148" number="2">5879017a2bf348b98cb50672b934df57@ngPost</segment>
    </segments>
  </file><file poster="LF1QUIBUAdkuf@ngPost.com" date="1791920865" subject="[2/10] - &quot;L2oxorYDqSshfpZq4f7H5W.rar&quot; yEnc (1/27) 18661647">
    <groups>
      <group>alt.binaries.nl</group>
      <group>alt.binaries.mp3</group>
      <group>alt.binaries.com</group>
      <group>alt.binaries.boneless</group>
    </groups>
    <segments>
      <segment bytes="716800" number="1">42824dc3249545cc88378307999309c0@ngPost</segment>
      <segment bytes="716800" number="2">7d3a0d07fce046dd8a725beed04b84f8@ngPost</segment>
      <segment bytes="716800" number="3">3d1d88302287461fa5e10a31058e1d10@ngPost</segment>
      <segment bytes="716800" number="4">d4b3a046dd744273ac0a6b3e255fc413@ngPost</segment>
      <segment bytes="716800" number="5">b92ea55b813a41c4a70e366ca7053743@ngPost</segment>
      <segment bytes="716800" number="6">4d30ed41e5c447cf9e6cbd8bce078d7b@ngPost</segment>
      <segment bytes="716800" number="7">8d45b84bf0a0416da2de7ae050319f5d@ngPost</segment>
      <segment bytes="716800" number="8">8fe6413e4e154eb99fdda6b692ae802f@ngPost</segment>
      <segment bytes="716800" number="9">81a2777e38d54634a543c526d5d84ab5@ngPost</segment>
      <segment bytes="716800" number="10">5f9eaec07f65407ea135bbfb04ce2733@ngPost</segment>
      <segment bytes="716800" number="11">e781a528d3374e1eb05b7e2f9b11b0c8@ngPost</segment>
      <segment bytes="716800" number="12">3fc56e56356448289b564dea90a3efdd@ngPost</segment>
      <segment bytes="716800" number="13">9afa32d1cdf245db9d127570c822cccf@ngPost</segment>
      <segment bytes="716800" number="14">9a001a102170415289079f69a0fb6503@ngPost</segment>
      <segment bytes="716800" number="15">add975808d334eb6b26fd1bb6f9383fa@ngPost</segment>
      <segment bytes="716800" number="16">bd91d8e27ee24a50b05d65aee72f4fee@ngPost</segment>
      <segment bytes="716800" number="17">a5d994396ac54ca5ad83e828c365b8ae@ngPost</segment>
      <segment bytes="716800" number="18">d9dd27e038254b94a4463d147e58288f@ngPost</segment>
      <segment bytes="716800" number="19">670aae724bc34ca58c0a509323659671@ngPost</segment>
      <segment bytes="716800" number="20">016a4f62b7ac449e9e14544ca4f18e7f@ngPost</segment>
      <segment bytes="716800" number="21">c1b638259235420aad5a992461f0ff12@ngPost</segment>
      <segment bytes="716800" number="22">1b3d44decac2441aa54a77a0d25fddbd@ngPost</segment>
      <segment bytes="716800" number="23">caa8a4ac238845709269f22e3437cad2@ngPost</segment>
      <segment bytes="716800" number="24">5fa273d0a71f4ed0bd64ecd7a46a8520@ngPost</segment>
      <segment bytes="716800" number="25">7d722db947704f36b597aaabf087d46e@ngPost</segment>
      <segment bytes="716800" number="26">1f74b362deed4e04b1010ad9d34a1f10@ngPost</segment>
      <segment bytes="24847" number="27">e73d76b914274daf9e325181e57600ec@ngPost</segment>
    </segments>
  </file></nzb>
