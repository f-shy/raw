# Quickstart

Install the sbx CLI, sign in, and run your first sandbox in about two minutes.

[.md](https://sandboxer.com/docs/quickstart.md)

## 1. Install the CLI

```
curl -fsSL https://sandboxer.com/install | sh
```

The installer puts a single static binary called `sbx` on your `PATH`, then runs `sbx onboard`, which:

1. opens your browser so you can sign in with GitHub, Google, an email code, or an email and password;
2. shows a short code that you approve on the [device page](https://sandboxer.com/device) — the CLI never sees your password;
3. if this is a new account, offers to open checkout for the $20/month plan. The first month is charged when you subscribe, and the plan renews monthly until you cancel.

Already have an account on another computer? Run `sbx login` instead; it finds your account and skips the questions it has already asked.

## 2. Create a sandbox

```
sbx new
```

```
creating sandbox… sb_k3v9x2mq (amber-fjord-lumen)
provisioning ▸ ready
  type      default  (4 vCPU, 8 GB RAM, 50 GB disk)
  url       https://amber-fjord-lumen.box.sandboxer.com
  ipv6      2a01:4f9:3a:1e2f::6
  auto-stop in 1h  (sbx extend sb_k3v9x2mq --hours 8)
```

What you just got:

| Machine | A full Ubuntu 24.04 virtual machine with root and systemd |
| --- | --- |
| Size | `default` — 4 vCPU, 8 GB RAM, 50 GB disk |
| Installed | Docker, Node, Python, Go, Rust, Chrome, `gh`, and coding agents (Claude Code, Codex, OpenCode, …) |
| Billing | Per second while it runs; nothing while it is stopped |
| Auto-stop | After one hour unless you extend it or pass `--no-auto-stop` |

Every command that takes a sandbox id also accepts `current` — the last sandbox you created in this shell — so you rarely need to copy ids.

## 3. Use it

```
sbx ssh                          # interactive shell as `user` (sudo works without a password)
sbx exec current "uname -a"      # run one command through the API, no SSH needed
sbx host current 3000            # print a public HTTPS URL for port 3000
sbx prompt "add a /health route and a test for it"   # hand a task to an agent inside
```

Start something long-running and leave it:

```
sbx ssh -- 'cd ~ && npx create-vite@latest app -t react-ts && cd app && npm i && nohup npm run dev -- --host 0.0.0.0 &'
sbx host current 5173
```

## 4. Stop it, then bring it back

```
sbx stop          # snapshots memory + disk, billing stops
sbx resume        # restores memory: the dev server is still running
```

Because Sandboxer snapshots memory on stop, `resume` gives you back the same processes, open files and shell sessions — not a fresh boot. If you change the size on resume (`--type large`), the sandbox cold-boots from its disk instead.

## 5. Make copies

```
sbx fork current                 # an independent copy, created in about a second
sbx snapshot current web-stack   # save a named template
sbx new --from web-stack         # start new sandboxes from it
```

## From code

Create an [API key](https://sandboxer.com/docs/api-keys) on the dashboard (or `sbx api-key create my-app --preset ci`), export it as `SANDBOXER_API_KEY`, then:

```
curl -sS -X POST https://sandboxer.com/api/v1/sandboxes \
  -H "Authorization: Bearer $SANDBOXER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"type":"default","ttlSeconds":3600}'
```

The create call returns `202` while the machine boots. Poll `GET /sandboxes/{id}` until `state` is `ready`, or let the SDK helper do it, or subscribe to the `sandbox.ready` [webhook](https://sandboxer.com/docs/webhooks).

## Next steps

- [Machines & sizes](https://sandboxer.com/docs/machines) — pick a size, see what is pre-installed
- [Environments & secrets](https://sandboxer.com/docs/environments) — give every new sandbox your keys and repos
- [Long-running tasks](https://sandboxer.com/docs/long-running) — keep work going for days
- [CLI reference](https://sandboxer.com/docs/cli) — every command and flag

[PreviousIntroduction](https://sandboxer.com/docs)

[Next Machines & sizes](https://sandboxer.com/docs/machines)
