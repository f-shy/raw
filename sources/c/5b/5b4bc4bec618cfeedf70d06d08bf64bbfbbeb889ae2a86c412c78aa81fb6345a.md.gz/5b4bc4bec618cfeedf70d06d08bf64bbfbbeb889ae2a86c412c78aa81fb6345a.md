Version: 18.x

This page lists the capabilities of the Teleport Infrastructure Identity Platform, organized by product.

The **Teleport Identity Infrastructure Platform** modernizes identity, access, and policy for infrastructure, for both human and non-human identities. Products include:

## Teleport Agentic Identity Framework

The **Teleport Agentic Identity Framework** combines Teleport identity, access, governance, and monitoring capabilities to secure AI agents and the infrastructure they access. It brings together cryptographic agent identity, ephemeral runtime isolation through [Beams](https://www.beams.run/), Model Context Protocol (MCP) server protection, and behavioral monitoring across the Teleport platform.

|  | **Enterprise (Cloud)** [Try for free](https://goteleport.com/signup) | **Enterprise (Self-Hosted)** | **Community Edition** |
| --- | --- | --- | --- |
| **Agent identity.** Issue cryptographic identities to AI agents: |  |  |  |
| Per-agent cryptographic certificates | ✔ | ✔ | ✖ |
| Agent-to-owner identity linkage | ✔ | ✔ | ✖ |
| Short-lived agent credentials with no standing privileges | ✔ | ✔ | ✖ |
| **MCP server access.** Treat Model Context Protocol servers as first-class protected resources in Teleport: |  |  |  |
| [MCP server enrollment and proxying](https://goteleport.com/docs/enroll-resources/mcp-access/) | ✔ | ✔ | ✔ |
| Identity-based access control for MCP traffic | ✔ | ✔ | ✔ |
| Per-tool audit events for MCP requests | ✔ | ✔ | ✔ |
| **Trusted runtimes ([Beams](https://www.beams.run/), beta).** Run agent sessions in isolated, ephemeral runtimes with built-in identity, controlled egress, and full audit: |  |  |  |
| Sandboxed agent runtime (Firecracker microVM) with ephemeral storage and short-lived injected identity | ✔ | ✖ | ✖ |
| Launch and manage beams via `tsh` and an MCP server | ✔ | ✖ | ✖ |
| Built-in inference proxy with bundled providers (OpenAI, Anthropic) and bring-your-own option | ✔ | ✖ | ✖ |
| Policy-controlled allowlist for external API egress | ✔ | ✖ | ✖ |
| Per-user limits on concurrent beams and shared inference usage | ✔ | ✖ | ✖ |
| Session-bound beam lifecycle (~24-hour maximum) with full audit trail | ✔ | ✖ | ✖ |
| **Agent enforcement.** Stop or constrain agent activity inline when policy is violated: |  |  |  |
| [Session and identity locks](https://goteleport.com/docs/identity-governance/locking/) | Available in Teleport Identity Governance | Available in Teleport Identity Governance | ✖ |
| [Device Trust](https://goteleport.com/docs/zero-trust-access/device-trust/guide/) for the human operator behind an agent | ✔ | ✔ | ✖ |
| [Per-Session MFA](https://goteleport.com/docs/zero-trust-access/authentication/per-session-mfa/) for sensitive agent actions | ✔ | ✔ | ✔ |
| **Agent behavior monitoring.** Detect anomalies in agent and human-plus-agent activity: |  |  |  |
| Identity threat patterns and anomaly surfacing | Available in Teleport Identity Security | Available in Teleport Identity Security | ✖ |
| [Session recording](https://goteleport.com/docs/reference/architecture/session-recording/) for agent sessions | ✔ | ✔ | ✔ |
| **AI infrastructure protection.** Apply identity-based access control to the systems that agents and humans use to build, train, and serve models: |  |  |  |
| Access control for model weights and training data stores ([applications](https://goteleport.com/docs/enroll-resources/application-access/getting-started/), [databases](https://goteleport.com/docs/enroll-resources/database-access/getting-started/)) | ✔ | ✔ | ✔ |
| Access control for GPU clusters ([Linux servers](https://goteleport.com/docs/enroll-resources/server-access/getting-started/), [Kubernetes](https://goteleport.com/docs/enroll-resources/kubernetes-access/getting-started/)) | ✔ | ✔ | ✔ |
| Access control for model registries and inference endpoints (applications, MCP servers) | ✔ | ✔ | ✔ |

## Teleport Zero Trust Access

**Teleport Zero Trust Access** provides AI agents, humans, and machines with least-privileged access to applications, servers, databases, Kubernetes clusters, and other resources across distributed infrastructures.

|  | **Enterprise (Cloud)** [Try for free](https://goteleport.com/signup) | **Enterprise (Self-Hosted)** | **Community Edition** |
| --- | --- | --- | --- |
| **User identity.** Authenticate users without passwords: |  |  |  |
| [Single Sign-On](https://goteleport.com/docs/zero-trust-access/sso/) | GitHub, Google Workspace, Microsoft Entra ID, Okta, SailPoint, OIDC, SAML, Teleport | GitHub, Google Workspace, Microsoft Entra ID, Okta, SailPoint, OIDC, SAML, Teleport | GitHub |
| User & Group Provisioning & Deprovisioning (SCIM & Custom Protocols), including Okta, Microsoft Entra ID, and SailPoint | Available In Teleport Identity Governance | Available In Teleport Identity Governance | ✖ |
| [Hardware Private Key Support](https://goteleport.com/docs/zero-trust-access/authentication/hardware-key-support/) (e.g., via YubiKey) | ✔ (External-connected HSM/KMS coming soon) | ✔ | ✖ |
| [Device Trust](https://goteleport.com/docs/zero-trust-access/device-trust/guide/): Require an up-to-date, registered device for each authentication. Teleport uses TPMs and secure enclaves to give every device a cryptographic identity. Restrict further by resource or MDM-authorization. | ✔ | ✔ | ✖ |
| [Per-Session MFA](https://goteleport.com/docs/zero-trust-access/authentication/per-session-mfa/) | ✔ | ✔ | ✔ |
| **Resource identity.** Assign a cryptographic identity to every Teleport Protected Resource: |  |  |  |
| Protecting: [MCP Servers](https://goteleport.com/docs/enroll-resources/mcp-access/), [Applications](https://goteleport.com/docs/enroll-resources/application-access/getting-started/), [Databases](https://goteleport.com/docs/enroll-resources/database-access/getting-started/), [Kubernetes Clusters](https://goteleport.com/docs/enroll-resources/kubernetes-access/getting-started/), [Linux Servers](https://goteleport.com/docs/enroll-resources/server-access/getting-started/), [Windows Servers](https://goteleport.com/docs/enroll-resources/desktop-access/introduction/), [Windows Desktops](https://goteleport.com/docs/enroll-resources/desktop-access/introduction/), Cloud Consoles & Resources (AWS, Azure, GCP), [GitHub](https://goteleport.com/docs/enroll-resources/application-access/cloud-apis/github-integration/) | ✔ | ✔ | ✔ (does not include Oracle support) |
| **Secure remote access.** Zero-trust, auditable access to your infrastructure: |  |  |  |
| Dynamic, self-updating inventory | ✔ | ✔ | ✔ |
| Supports MCP servers, SSH, RDP, Kubernetes, Databases, AWS, Azure, GCP API and CLI, Web applications and services, TCP endpoints for Linux, Windows and MacOS. | ✔ | ✔ | ✔ |
| [Machines](https://goteleport.com/docs/machine-workload-identity/) and [workloads](https://goteleport.com/docs/machine-workload-identity/workload-identity/introduction/) | Available in Teleport Machine & Workload Identity | Available in Teleport Machine & Workload Identity | Available in Teleport Machine & Workload Identity |
| Agentless Integration with [OpenSSH Servers](https://goteleport.com/docs/enroll-resources/server-access/openssh/openssh-agentless/) | ✔ | ✔ | ✔ |
| [IP-Based Restrictions](https://goteleport.com/docs/zero-trust-access/authentication/ip-pinning/) | ✔ | ✔ | ✖ |
| [Teleport VNet](https://goteleport.com/docs/connect-your-client/teleport-clients/vnet/) | ✔ | ✔ | ✔ |
| **Short-lived privileges.** Ephemeral authorization granted through short-lived certificates: |  |  |  |
| [Role-Based Access Control](https://goteleport.com/docs/zero-trust-access/rbac-get-started/role-templates/) | ✔ | ✔ | ✔ |
| [Just-in-Time Access Requests & Reviews](https://goteleport.com/docs/identity-governance/access-requests/resource-requests/) | Available in Teleport Identity Governance | Available in Teleport Identity Governance | Only can request roles through CLI |
| **Session recording and interactive controls.** Record, replay, join, and moderate interactive sessions: |  |  |  |
| [Session Recording with Playback](https://goteleport.com/docs/reference/architecture/session-recording/) | ✔ | ✔ | ✔ |
| [Enhanced Session Recording](https://goteleport.com/docs/enroll-resources/server-access/guides/bpf-session-recording/) | ✔ | ✔ | ✔ |
| [Recording Proxy Mode](https://goteleport.com/docs/reference/architecture/session-recording/#record-at-the-proxy-service) | ✖ | ✔ | ✔ |
| Live Sessions View | SSH, Kubernetes, Desktops, Databases | SSH, Kubernetes, Desktops, Databases | SSH, Kubernetes, Desktops, Databases |
| Protocol-Level Events, for all supported resources | ✔ | ✔ | ✔ |
| [Dual Authorization](https://goteleport.com/docs/identity-governance/access-requests/) | ✔ | ✔ | ✖ |
| [Session Sharing & Moderation](https://goteleport.com/docs/zero-trust-access/authentication/joining-sessions/) | ✔ | ✔ | ✖ |
| **Identity-based audit events:** |  |  |  |
| [Structured Audit Logs](https://goteleport.com/docs/reference/deployment/monitoring/audit/) | ✔ | ✔ | ✔ |
| [Export to SIEM](https://goteleport.com/docs/zero-trust-access/export-audit-events/) | ✔ | ✔ | ✔ |
| **Regulatory standards and frameworks:** |  |  |  |
| [FedRAMP Control](https://goteleport.com/docs/zero-trust-access/compliance-frameworks/fedramp/) | ✖ | ✔ | ✖ |
| FIPS-compliant binaries for FedRAMP (Low, Moderate, High) | ✖ | ✔ | ✖ |
| DORA, SOX, ISO, NIS2, PCI DSS, SOC 2, HIPAA, NIST | ✔ | ✔ | Limited |

## Teleport Machine & Workload Identity

**Teleport Machine & Workload Identity** is a non-human identity management solution that secures machine-to-machine communication with short-lived certificates, access control, and auditability.

|  | **Enterprise (Cloud)** [Try for free](https://goteleport.com/signup) | **Enterprise (Self-Hosted)** | **Community Edition** |
| --- | --- | --- | --- |
| **Service Discovery:** Live inventory of machine and workload identities for CI/CD jobs, microservices, and others | ✔ | ✔ | ✔ |
| **Issuance:** Provisions cryptographic identities for [machines](https://goteleport.com/docs/machine-workload-identity/getting-started/) and [workloads](https://goteleport.com/docs/machine-workload-identity/workload-identity/getting-started/), eliminating anonymous computing and the need for static over-privileged users and automating certificate rotation | ✔ | ✔ | ✔ |
| **Secretless Authentication:** Eliminates the need for API keys and long-term secrets with short-lived certificates. | ✔ | ✔ | ✔ |
| **Ephemeral Authorization:** With granular ABAC/RBAC for workload interactions | ✔ | ✔ | ✔ |
| **Auditability:** Audit data, exportable to SIEMs, for compliance reporting & reviews | ✔ | ✔ | ✔ |
| **Integration:** Supports open-source policy agents, dev tool APIs, and Cloud IAM. Others include Jenkins, Github actions, Terraform Cloud, AWS Roles anywhere and more. | ✔ | ✔ | ✔ |
| **HSM and [TPM support](https://goteleport.com/docs/machine-workload-identity/deployment/linux-tpm/)** for bootstrapping, joining, and encryption | ✔ | ✔ | ✖ |
| **Open Standards** - JWT, SPIFFE, x509 and others to avoid vendor lock-in | ✔ | ✔ | ✔ |
| **[External PKI integration](https://goteleport.com/docs/reference/machine-workload-identity/workload-identity/issuer-override/):** Configure an external PKI hierarchy to use for issuing SPIFFE SVIDs | ✔ | ✔ | ✖ |
| [**Sigstore attestation:**](https://goteleport.com/docs/reference/machine-workload-identity/workload-identity/sigstore-attestation/) Enforce validation of container supply-chain security when issuing SPIFFE SVIDs | ✔ | ✔ | ✖ |

## Teleport Identity Governance

**Teleport Identity Governance** hardens and monitors identities for both human and non-human identities.

|  | **Enterprise (Cloud)** [Try for free](https://goteleport.com/signup) | **Enterprise (Self-Hosted)** | **Community Edition** |
| --- | --- | --- | --- |
| [JIT Access Requests](https://goteleport.com/docs/identity-governance/access-requests/): Grant only those privileges necessary to complete the task at hand. Remove the need for super-privileged accounts. | ✔ | ✔ | Only can request roles through CLI |
| Automatic Access Requests & Approvals: Automate pre-defined workflows based on RBAC, ABAC, or context-based authorization. | ✔ | ✔ | ✖ |
| [Access Lists & Access Reviews](https://goteleport.com/docs/identity-governance/access-lists/): Review access requests using Slack, PagerDuty, Microsoft Teams, Jira and ServiceNow. Assign managers, automate mandatory reviews, and implement custom review logic using our API and Go SDK. Integrates with AWS Identity Center. | ✔ | ✔ | ✖ |
| [Session & Identity Locks](https://goteleport.com/docs/identity-governance/locking/): Lock suspicious or compromised identities and stop all their activity across all protocols and services. | ✔ | ✔ | ✖ |
| User & Group Provisioning & Deprovisioning (SCIM & Custom Protocols), including Okta, Microsoft Entra ID, and SailPoint | ✔ | ✔ | ✖ |
| [Access Monitoring & Response](https://goteleport.com/docs/identity-governance/access-monitoring/): Detect overly broad privileges and inspect sessions that are not using strong protection, such as multi-factor authentication or device trust. Alert on access violations and purge unused permissions with automated access rules. | ✔ | ✔ | ✖ |
| [Okta integration](https://goteleport.com/docs/identity-governance/integrations/okta/): Configure Teleport to import and grant access to Okta applications and user groups. | ✔ | ✔ | ✖ |
| Microsoft Entra ID directory synchronization and SSO [integration](https://goteleport.com/docs/zero-trust-access/sso/integrate-idp/entra-id/) | ✔ | ✔ | ✖ |

## Teleport Identity Security

**Teleport Identity Security** identifies & mitigates risk in access paths.

|  | **Enterprise (Cloud)** [Try for free](https://goteleport.com/signup) | **Enterprise (Self-Hosted)** | **Community Edition** |
| --- | --- | --- | --- |
| Access Graph: Import and analysis of AWS, Azure, Okta, Microsoft Entra, GitLab and AWS IAM roles | ✔ | ✔ | ✖ |
| Discover secrets, SSH Key Scanning | ✔ | ✔ | ✖ |
| Discover standing privileges | ✔ | ✔ | ✖ |
| Analyze shadow access and drift of security posture | ✔ | ✔ | ✖ |
| Investigate identity vulnerabilities and potential exposures | ✔ | ✔ | ✖ |
| Monitor critical assets with [Crown Jewel](https://goteleport.com/docs/identity-security/usage/crown-jewels/) Alerting | ✔ | ✔ | ✖ |
| [Session Recording Summaries and Session Recording Search](https://goteleport.com/docs/identity-security/session-summaries/session-search/) | ✔ | ✔ | ✖ |
| Identity Activity Center | ✔ | ✔ | ✖ |

## Platform integrations, management, licensing, and deployment

|  | **Enterprise (Cloud)** [Try for free](https://goteleport.com/signup) | **Enterprise (Self-Hosted)** | **Community Edition** |
| --- | --- | --- | --- |
| **Integrations:** |  |  |  |
| Infrastructure as Code (IaC): Terraform, K8s Operator | ✔ | ✔ | ✔ |
| Cloud Providers: AWS, Azure, GCP | ✔ | ✔ | ✔ |
| Security Information & Event Management (SIEM): Elastic, Splunk, Panther, and anything else that integrates with Fluentd | ✔ | ✔ | ✔ |
| ITSM: ServiceNow, JIRA | ✔ | ✔ | ✖ |
| Access Request Integration: Slack, Teams, Discord, Mattermost, PagerDuty, Opsgenie, Email | ✔ | ✔ | ✔ |
| [Hardware Private Key Support](https://goteleport.com/docs/zero-trust-access/authentication/hardware-key-support/) (e.g., via YubiKey) | ✔ (External-connected HSM/KMS coming soon) | ✔ | ✖ |
| [Hardware Security Module support](https://goteleport.com/docs/installation/self-hosted/private-keys/hsm/) for encryption at rest | ✔ (External-connected HSM/KMS coming soon) | ✔ | ✖ |
| **Management and licensing:** |  |  |  |
| Annual or multi-year contracts, volume discounts | ✔ | ✔ | ✖ |
| Anonymized Usage Tracking | ✔ | ✔ | Opt-in |
| [Backend support](https://goteleport.com/docs/reference/deployment/backends/) | All data is stored in DynamoDB and S3 with server-side encryption. | Any S3-compatible storage for session records, many managed backends for custom audit log storage | Any S3-compatible storage for session records, many managed backends for custom audit log storage. |
| Multi-region failover using Cockroach DB | ✔ | ✔ | ✖ |
| Data storage location | Data is stored in Teleport's AWS infrastructure with audit logs/sessions optionally in customer AWS accounts. Proxy Service instances are deployed across the world for low-latency access. | Can store data anywhere in the world, on most managed cloud backends | Can store data anywhere in the world, on most managed cloud backends |
| License | Commercial | Commercial | Commercial for binaries, with restrictions: Free usage for companies with <100 employees and <US$10M annual revenue. Code on GitHub distributed via AGPL-3.0 |
| Publicly accessible domain name | A subdomain of teleport.sh | Custom | Custom |
| [Support](https://support.goteleport.com/hc/en-us/articles/16562919750419-Priority-Support) | 24x7 (Severity 1) support with premium SLAs and account managers. | 24x7 (Severity 1) support with premium SLAs and account managers | Slack community |
| Version support | Deploys last stable release with 2-3 week lag for stability. | All supported releases available to install and download. | All supported releases available to install and download. |
| **Deployment options:** |  |  |  |
| Teleport cloud deployment | ✔ | ✖ | ✖ |
| Self-hosted deployment | ✖ | ✔ | ✔ |
| Multi-Region High Availability | ✔ (Teleport service) | ✔ (Customer-implemented, via a [supported blueprint](https://goteleport.com/docs/installation/self-hosted/deployments/multi-region-blueprint/)) | ✖ |
| FIPS-compliant binaries available for FedRAMP, including Low, Moderate & High | ✖ | ✔ | ✖ |
